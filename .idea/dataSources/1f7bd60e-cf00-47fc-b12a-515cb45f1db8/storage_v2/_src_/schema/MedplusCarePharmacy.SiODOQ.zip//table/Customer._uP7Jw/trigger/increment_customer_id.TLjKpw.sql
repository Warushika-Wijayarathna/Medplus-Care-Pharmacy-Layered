create definer = root@localhost trigger increment_customer_id
    before insert
    on Customer
    for each row
BEGIN
    UPDATE AutoIncrement_Customer SET next_id = next_id + 1;
    SET NEW.cust_id = CONCAT('C', LPAD((SELECT next_id FROM AutoIncrement_Customer), 4, '0'));
END;

